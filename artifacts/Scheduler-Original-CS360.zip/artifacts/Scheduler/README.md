# Scheduler

A modern, intuitive Android productivity application designed for flexible event management and automated notifications. Built with **Jetpack Compose** and **Room Database**, the Scheduler provides a professional experience for organizing personal and professional milestones.

## 🚀 Key Features

- **Hierarchical Organization**: Create individual events or group them into "Collections" (folders) for major projects or trips.
- **Dynamic Chronological Filtering**: View your schedule through "Today," "This Week," or "This Month" lenses, strictly following standard calendar boundaries.
- **Advanced Search**: Real-time querying of events and collections with direct navigation to results.
- **Automated SMS Alerts**: Stay on track with automated notifications triggered 30 minutes before any scheduled event.
- **Secure Persistence**: All data, including user profiles and events, is stored locally in a secure SQLite database.

## 🛡️ Security & Privacy

- **Salted Hashing**: User passwords are never stored in plaintext. The app uses the **PBKDF2 with HMAC-SHA256** algorithm with a unique per-user salt to ensure top-tier credential protection.
- **Dynamic Permissions**: The app follows the principle of least privilege, requesting SMS permissions only when the user explicitly enables alerts.

## 🛠️ Technical Stack

- **Language**: 100% Kotlin
- **UI Framework**: Jetpack Compose (Material 3)
- **Database**: Room Persistence Library (SQLite)
- **Architecture**: MVVM (Model-View-ViewModel) with Kotlin Coroutines and StateFlow
- **Dependency Management**: Gradle Version Catalog (libs.versions.toml)

## 📱 Getting Started

1.  **Clone the Repository**:
    ```bash
    git clone [repository-url]
    ```
2.  **Open in Android Studio**:
    Open the root folder in Android Studio (Ladybug or newer recommended).
3.  **Build and Run**:
    Select an emulator (API 24+) or a physical device and click the **Run** button.

## 📜 Permissions

- **`android.permission.SEND_SMS`**: Required for the automated notification feature. The app remains fully functional if this permission is denied.

---
*Developed as part of the CS-360 Mobile Architecture & Programming curriculum.*
